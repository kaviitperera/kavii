const Home= () => {
    window.location.href = 'Index.html';
}

const Contactme= () => {
    window.location.href = 'Gallery.html';
}

const Aboutme= () => {
    window.location.href = 'About.html';
}

const Education= () => {
    window.location.href = 'Achievements.html';
}

